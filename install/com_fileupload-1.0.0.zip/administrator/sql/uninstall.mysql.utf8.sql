DROP TABLE IF EXISTS `#__fileupload_files`;
