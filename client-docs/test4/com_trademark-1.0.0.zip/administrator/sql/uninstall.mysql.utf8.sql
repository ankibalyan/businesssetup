DROP TABLE IF EXISTS `#__bstrademarks`;
