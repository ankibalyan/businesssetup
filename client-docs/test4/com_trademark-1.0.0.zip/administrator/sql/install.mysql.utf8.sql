CREATE TABLE IF NOT EXISTS `#__bstrademarks` (
`id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,

`asset_id` INT(10) UNSIGNED NOT NULL DEFAULT '0',

`ordering` INT(11)  NOT NULL ,
`state` TINYINT(1)  NOT NULL ,
`checked_out` INT(11)  NOT NULL ,
`checked_out_time` DATETIME NOT NULL DEFAULT '0000-00-00 00:00:00',
`created_by` INT(11)  NOT NULL ,
`record_id` BIGINT(20)  NOT NULL ,
`user_id` BIGINT(20)  NOT NULL ,
`service_id` BIGINT(20)  NOT NULL ,
`applicant_name` VARCHAR(255)  NOT NULL ,
`doc_attachment` VARCHAR(255)  NOT NULL ,
`doc_address` VARCHAR(255)  NOT NULL ,
`type` VARCHAR(255)  NOT NULL ,
`all_directors_fullname` VARCHAR(255)  NOT NULL ,
`signatory_fullname` VARCHAR(255)  NOT NULL ,
`signatory_phoneno` BIGINT(12)  NOT NULL ,
`signatory_email` VARCHAR(255)  NOT NULL ,
`signatory_nationality` VARCHAR(255)  NOT NULL ,
`signatory_gaurdian_name` VARCHAR(255)  NOT NULL ,
`signatory_address` TEXT NOT NULL ,
`signatory_age` INT(3)  NOT NULL ,
`trademark_name` VARCHAR(255)  NOT NULL ,
`trademark_desc` TEXT NOT NULL ,
`trademark_state` VARCHAR(255)  NOT NULL ,
`service_address` TEXT NOT NULL ,
PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT COLLATE=utf8_general_ci;

