
/**
 * jQuery Cookie plugin
 *
 * Copyright (c) 2010 Klaus Hartl (stilbuero.de)
 * Dual licensed under the MIT and GPL licenses:
 * http://www.opensource.org/licenses/mit-license.php
 * http://www.gnu.org/licenses/gpl.html
 *
 */
jQuery.noConflict();

jQuery.cookie = function (key, value, options) {

    // key and at least value given, set cookie...
    if (arguments.length > 1 && String(value) !== "[object Object]") {
        options = jQuery.extend({}, options);

        if (value === null || value === undefined) {
            options.expires = -1;
        }

        if (typeof options.expires === 'number') {
            var days = options.expires, t = options.expires = new Date();
            t.setDate(t.getDate() + days);
        }

        value = String(value);

        return (document.cookie = [
            encodeURIComponent(key), '=',
            options.raw ? value : encodeURIComponent(value),
            options.expires ? '; expires=' + options.expires.toUTCString() : '', // use expires attribute, max-age is not supported by IE
            options.path ? '; path=' + options.path : '',
            options.domain ? '; domain=' + options.domain : '',
            options.secure ? '; secure' : ''
        ].join(''));
    }

    // key and possibly options given, get cookie...
    options = value || {};
    var result, decode = options.raw ? function (s) { return s; } : decodeURIComponent;
    return (result = new RegExp('(?:^|; )' + encodeURIComponent(key) + '=([^;]*)').exec(document.cookie)) ? decode(result[1]) : null;
};

//
var page_loaded = false;
// animations
var elementsToAnimate = [];
//
var headerHeight = ''

jQuery(document).ready(function() {		

	//See more in pvt ltd
	jQuery(".rmtxt").hide();
	jQuery("#seemor").click(function() {
		jQuery(".rmtxt").toggle();
	});

	//TO bring Popup 
	jQuery("#popu").click(function() {
		jQuery("#fade").show();
		jQuery("#light").show();
		jQuery("#popuclose").show();
	});
	jQuery("#fade").click(function() {
		jQuery("#popuclose").hide();
		jQuery("#fade").hide();
		jQuery("#light").hide();
	});
	jQuery('#popuclose').click(function() {
		jQuery("#popuclose").hide();
		jQuery("#fade").hide();
		jQuery("#light").hide();
	});

	//tool tip and pop over
	 jQuery('[data-toggle="tooltip"]').tooltip({'placement': 'top'});
	 // jQuery('[data-toggle="popover"]').popover({trigger: 'hover','placement': 'top'});
	 // //$('.arc_section').popover();

	jQuery('#sharecapital').change(function(event) {

		share_cap_val = jQuery(this).val();
		gov_popup_con = jQuery('#companyregistrationpvtltd_gov1_pop'+share_cap_val).html();
		//jQuery('#companyregistrationpvtltd_gov1').attr('title',gov_popup_con);
		//jQuery('[data-toggle="tooltip"]').tooltip({'placement': 'top'});
		jQuery('#companyregistrationpvtltd_gov1').tooltip('hide')
          .attr({
          	'data-original-title': gov_popup_con,
          	title: gov_popup_con
          })
          .tooltip('fixTitle')
          .tooltip('show');
	});


		//get the total at load
	f1=jQuery("#total_gov").val();
	f2=jQuery("#total_price").val();
	ttl = parseInt(f1) + parseInt(f2);
	jQuery("#pc_tot").val(ttl); //put the total in prce cal

	jQuery("#companyregistrationpvtltd_gov1").click(function(event) {
		event.preventDefault();
		dyndata = jQuery('#companyregistrationpvtltd_gov1').html();
		jQuery('#light').append(dyndata);
		jQuery("#popu").trigger('click');
	});
	jQuery("#mailid").change(function (){
			errFlag=0;
			var mailid=jQuery("#mailid").val();
			var atpos = mailid.indexOf("@");
			var dotpos = mailid.lastIndexOf(".");
				if (atpos< 1 || dotpos<atpos+2 || dotpos+2>=mailid.length) 
				{
					alert("Not a valid e-mail address");
					errFlag=1;
				}  
				else 
				{
					errFlag=0;
				} 
			});
	jQuery("#firstname").blur(function() {
		jQuery('#contact').select();
	});			
			
				
		jQuery("#slist").change(function (){
				var state=jQuery("#slist").val();
					if(state==0){
					errFlag=1;
					alert("Please select a state");
					}
		});
		jQuery("#contact").change(function (){
		var namevalidate= /([a-zA-Z])/;
		var contact=jQuery("#contact").val();
		if( namevalidate.test(contact) ) {
		 alert("Contact number not valid");
		errFlag=1;
		} else errFlag=0;
		});
	
		jQuery("#myform").submit(function (){
			errFlag=0;
			var namevalidate= /([a-zA-Z])/;
			var contact=jQuery("#contact").val();
		
				if( namevalidate.test(contact) ) {
				errFlag=1;
					alert("Contact number not valid");
					
				}
					var state=jQuery("#slist").val();
					if(state==0){
					errFlag=1;
					alert("Please select a state");
					}
			var mailid=jQuery("#mailid").val();
			var atpos = mailid.indexOf("@");
			var dotpos = mailid.lastIndexOf(".");
				if (atpos< 1 || dotpos<atpos+2 || dotpos+2>=mailid.length) {
					errFlag=1;
					alert("Not a valid e-mail Address");
				}
				
					if (jQuery("#cdnp").attr('checked')){
					
			var mailid=jQuery("#promotersmail").val();
			var atpos = mailid.indexOf("@");
			var dotpos = mailid.lastIndexOf(".");
				if (atpos< 1 || dotpos<atpos+2 || dotpos+2>=mailid.length) {
					errFlag=1;
					alert("Not a valid promotor e-mail Address");
				}
				} 
			if(errFlag==1){
				return  false ;
				} else	{
				return true;
				}
		});
	jQuery("#directorMail").change(function (){
			errFlag=0;
			var mailid=jQuery("#directorMail").val();
			var atpos = mailid.indexOf("@");
			var dotpos = mailid.lastIndexOf(".");
				if (atpos< 1 || dotpos<atpos+2 || dotpos+2>=mailid.length) 
				{
					alert("Not a valid e-mail address");
					errFlag=1;
				}  
				else 
				{
					errFlag=0;
				} 
			});
				
		jQuery("#promotersshare").change(function (){
		var namevalidate= /([a-zA-Z])/;
 var share=jQuery("#promotersshare").val();
 if( namevalidate.test(share) ) {
		 alert("% of share holding not valid");
		errFlag=1;
		} else errFlag=0;
		});
		
		jQuery("#directordetails").submit(function (){
			errFlag=0;
			var mailid=jQuery("#directorMail").val();
			var atpos = mailid.indexOf("@");
			var dotpos = mailid.lastIndexOf(".");
				if (atpos< 1 || dotpos<atpos+2 || dotpos+2>=mailid.length) {
					alert("Not a valid e-mail address");
					errFlag=1;
				}
		/* 	var passport=jQuery("#passport").val();
			var adharcard=jQuery("#adharcard").val();
			var electioncard=jQuery("#electioncard").val();
			var drivinglicence=jQuery("#drivinglicence").val();
			var mobilebill=jQuery("#mobilebill").val();
			var electricitybill=jQuery("#electricitybill").val();
			var telephonebill=jQuery("#telephonebill").val();
			var bankstatement=jQuery("#bankstatement").val();
			var namevalidate= /([a-zA-Z])/;
			var share=jQuery("#promotersshare").val();
			
			if(passport=="" && adharcard=="" && electioncard=="" && drivinglicence=="")
			{
			alert("Upload any one Identity Proof")
			errFlag=1;
			}
			
			if(mobilebill=="" && electricitybill=="" && telephonebill=="" && bankstatement=="")
			{
			alert("Upload any one Address Proof")
			errFlag=1;
			} */
			
			 var atpos = directormail.indexOf("@");
			 var dotpos = directormail.lastIndexOf(".");
			 if (atpos< 1 || dotpos<atpos+2 || dotpos+2>=directormail.length) {
			 alert("Not a valid e-mail address");
			 errFlag=1;
			}
			if( namevalidate.test(share) ) {
				alert("% of share holding not valid");
				errFlag=1;
			}
				
			if(errFlag==1){
			alert("Submited")
				return false;
				} else {
				return true;
				}
		});
	// jQuery("#sharecapital").change(function(){
	// 				var statelist = jQuery("#statelist").val();
	// 				var numdirectors = jQuery("#numdirectors").val();
	// 				var sharecapital = jQuery("#sharecapital").val();
	// 				if(sharecapital==0)	{ alert("Please select Share capital"); return false; }
	// 				if(statelist==0)	{ alert("Please select State"); return false; }
	// 				if(numdirectors==0){ alert("Please select no of directors"); return false; }
						
	// 		// document.getElementById("fs").style.display = "none";
	// 		// document.getElementById("spt").style.display = "block";
	// });		
	jQuery("#s2").click(function(){

					var statelist = jQuery("#statelist").val();
					var numdirectors = jQuery("#numdirectors").val();
					var sharecapital = jQuery("#sharecapital").val();
					if(statelist==0)	{ alert("Please select State"); return false; }
					if(numdirectors==0){ alert("Please select no of directors"); return false; }
					if(sharecapital==0)	{ alert("Please select Share capital"); return false; }
			//document.getElementById("fs").style.display = "none";
			//document.getElementById("spt").style.display = "block";
	});

	jQuery("#companyregistrationpvtltd").click(function(){
			v1 = document.getElementById("companyregistrationpvtltd_gov1").innerHTML;
			v2 = document.getElementById("companyregistrationpvtltd_price1").innerHTML;
			
		jQuery("#companyregistrationpvtltd_gov").val(v2);
		jQuery("#companyregistrationpvtltd_price").val(v1);
	});
	result = 0;
	//jQuery("#light").html('');
	jQuery("#RegistrationForm1").submit(function(){
		
		var statelist = jQuery("#statelist").val();
		var numdirectors = jQuery("#numdirectors").val();
		var sharecapital = jQuery("#sharecapital").val();
		if(statelist==0)	{ alert("Please select State"); return false; }
		if(numdirectors==0){ alert("Please select no of directors"); return false; }
		if(sharecapital==0)	{ alert("Please select Share capital"); return false; }
		
		v22=document.getElementById("govt").innerHTML;
		v21=document.getElementById("pubt").innerHTML;
		jQuery("#total_gov").val(v22);
		jQuery("#total_price").val(v21);
		v1 = document.getElementById("companyregistrationpvtltd_gov1").innerHTML;
		v2 = document.getElementById("companyregistrationpvtltd_price1").innerHTML;
				
		jQuery("#companyregistrationpvtltd_gov").val(v2);
		jQuery("#companyregistrationpvtltd_price").val(v1);

		result = 0;

		jQuery.ajax({
			url: 'http://bluesnpinks.com/businesssetup/checklogin.php',
			async:false,
			success: function (data) {
				console.log("success");
				result = data;
			}
		});
		if(result=='0' || result==0){
				jQuery('#notify').show();
				jQuery("#notify").html('Please login/Register <a target="_blank" href="http://bluesnpinks.com/businesssetup/index.php/login">here</a> to proceed further.');
				return false;
		}
	});
	function showMsg(hasCurrentJob, sender) {
        if (hasCurrentJob == "True") {
            alert("The current clients has a job in progress. No changes can be saved until current job completes");
            if (sender != null) {
                sender.preventDefault();
            }
            return false;
        }
    }

	jQuery("#cbs1").click(function(){
			// document.getElementById("fs").style.display = "block";
			// document.getElementById("spt").style.display = "none";
	});

		jQuery("#cdnp").change(function(){
			if (jQuery("#cdnp").attr('checked'))
    		{
				document.getElementById("dnp").style.display = "none";
				jQuery("#promotersname").attr("required", false);
				jQuery("#promotersmail").attr("required", false);
				jQuery("#promotersshare").attr("required", false);
				
			}
			else
			{
				document.getElementById("dnp").style.display = "block";
				jQuery("#promotersname").attr("required", "true");
				jQuery("#promotersmail").attr("required", "true");
				jQuery("#promotersshare").attr("required", "true");
			}
	});
	jQuery("#ptltt1").click(function (){
		if(jQuery("#ptltt1").attr('checked'))
		{
			document.getElementById("ptl1t1").style.textDecoration = "none";
			document.getElementById("ptlt1").style.textDecoration = "none";
			v1 = document.getElementById("ptl1t1").innerHTML;
			v2 = document.getElementById("ptlt1").innerHTML;
			
			f1 = document.getElementById("govt").innerHTML;
			f2 = document.getElementById("pubt").innerHTML;
			
			ff1 = parseInt(f1) + parseInt(v1);
			ff2 = parseInt(f2) + parseInt(v2);
			
			document.getElementById("govt").innerHTML = ff1;
			document.getElementById("pubt").innerHTML = ff2;
			
			ttl = parseInt(ff1) + parseInt(ff2);
			document.getElementById("pc_tot").innerHTML = ttl;

		}
		else
		{
			document.getElementById("ptl1t1").style.textDecoration = "line-through";
			document.getElementById("ptlt1").style.textDecoration = "line-through";
			v1 = document.getElementById("ptl1t1").innerHTML;
			v2 = document.getElementById("ptlt1").innerHTML;
			
			f1 = document.getElementById("govt").innerHTML;
			f2 = document.getElementById("pubt").innerHTML;
			
			ff1 = parseInt(f1) - parseInt(v1);
			ff2 = parseInt(f2) - parseInt(v2);
			
			document.getElementById("govt").innerHTML = ff1;
			document.getElementById("pubt").innerHTML = ff2;
			ttl = parseInt(ff1) + parseInt(ff2);
			document.getElementById("pc_tot").innerHTML = ttl;
		}

	});

	jQuery("#ptltt2").click(function (){
		if(jQuery("#ptltt2").attr('checked'))
		{
			document.getElementById("ptl1t2").style.textDecoration = "none";
			document.getElementById("ptlt2").style.textDecoration = "none";
		
			v1 = document.getElementById("ptl1t2").innerHTML;
			v2 = document.getElementById("ptlt2").innerHTML;
			
			f1 = document.getElementById("govt").innerHTML;
			f2 = document.getElementById("pubt").innerHTML;
			
			ff1 = parseInt(f1) + parseInt(v1);
			ff2 = parseInt(f2) + parseInt(v2);
			
			document.getElementById("govt").innerHTML = ff1;
			document.getElementById("pubt").innerHTML = ff2;
			ttl = parseInt(ff1) + parseInt(ff2);
			document.getElementById("pc_tot").innerHTML = ttl;
		}
		else
		{
			document.getElementById("ptl1t2").style.textDecoration = "line-through";
			document.getElementById("ptlt2").style.textDecoration = "line-through";
			
			v1 = document.getElementById("ptl1t2").innerHTML;
			v2 = document.getElementById("ptlt2").innerHTML;
			
			f1 = document.getElementById("govt").innerHTML;
			f2 = document.getElementById("pubt").innerHTML;
			
			ff1 = parseInt(f1) - parseInt(v1);
			ff2 = parseInt(f2) - parseInt(v2);
			
			document.getElementById("govt").innerHTML = ff1;
			document.getElementById("pubt").innerHTML = ff2;
			ttl = parseInt(ff1) + parseInt(ff2);
			document.getElementById("pc_tot").innerHTML = ttl;
		}
		
		jQuery("#ptl1t2_price").val(v2);
		jQuery("#ptlt2_gov").val(v1);
	});
	jQuery("#ptltt3").click(function (){
		if(jQuery("#ptltt3").attr('checked'))
		{
			document.getElementById("ptl1t3").style.textDecoration = "none";
			document.getElementById("ptlt3").style.textDecoration = "none";
		
			v1 = document.getElementById("ptl1t3").innerHTML;
			v2 = document.getElementById("ptlt3").innerHTML;
			
			f1 = document.getElementById("govt").innerHTML;
			f2 = document.getElementById("pubt").innerHTML;
			
			ff1 = parseInt(f1) + parseInt(v1);
			ff2 = parseInt(f2) + parseInt(v2);
			
			document.getElementById("govt").innerHTML = ff1;
			document.getElementById("pubt").innerHTML = ff2;
			ttl = parseInt(ff1) + parseInt(ff2);
			document.getElementById("pc_tot").innerHTML = ttl;
		}
		else
		{
			document.getElementById("ptl1t3").style.textDecoration = "line-through";
			document.getElementById("ptlt3").style.textDecoration = "line-through";
			
			v1 = document.getElementById("ptl1t3").innerHTML;
			v2 = document.getElementById("ptlt3").innerHTML;
			
			f1 = document.getElementById("govt").innerHTML;
			f2 = document.getElementById("pubt").innerHTML;
			
			ff1 = parseInt(f1) - parseInt(v1);
			ff2 = parseInt(f2) - parseInt(v2);
			document.getElementById("govt").innerHTML = ff1;
			document.getElementById("pubt").innerHTML = ff2;
			ttl = parseInt(ff1) + parseInt(ff2);
			document.getElementById("pc_tot").innerHTML = ttl;
		}		
		jQuery("#ptl1t3_price").val(v2);
		jQuery("#ptlt3_gov").val(v1);
	});

	jQuery("#ptltt4").click(function (){
		if(jQuery("#ptltt4").attr('checked'))
		{
			document.getElementById("ptlt4").style.textDecoration = "none";
			
			v2 = document.getElementById("ptlt4").innerHTML;
			
			f1 = document.getElementById("govt").innerHTML;
			f2 = document.getElementById("pubt").innerHTML;
			
			ff2 = parseInt(f2) + parseInt(v2);
			document.getElementById("pubt").innerHTML = ff2;
			ttl = parseInt(f1) + parseInt(ff2);
			document.getElementById("pc_tot").innerHTML = ttl;
		}
		else
		{
			document.getElementById("ptlt4").style.textDecoration = "line-through";
			
			v2 = document.getElementById("ptlt4").innerHTML;
			
			f1 = document.getElementById("govt").innerHTML;
			f2 = document.getElementById("pubt").innerHTML;
			
			ff2 = parseInt(f2) - parseInt(v2);
			
			document.getElementById("pubt").innerHTML = ff2;
			ttl = parseInt(f1) + parseInt(ff2);
			document.getElementById("pc_tot").innerHTML = ttl;
		}
		
		jQuery("#ptl1t4_price").val(v2);
	});

	jQuery("#ptltt5").click(function (){
		if(jQuery("#ptltt5").attr('checked'))
		{
			document.getElementById("ptlt5").style.textDecoration = "none";
			
			v2 = document.getElementById("ptlt5").innerHTML;
			
			f1 = document.getElementById("govt").innerHTML;
			f2 = document.getElementById("pubt").innerHTML;
			
			ff2 = parseInt(f2) + parseInt(v2);
			document.getElementById("pubt").innerHTML = ff2;
			ttl = parseInt(f1) + parseInt(ff2);
			document.getElementById("pc_tot").innerHTML = ttl;
		}
		else
		{
			document.getElementById("ptlt5").style.textDecoration = "line-through";
			
			v2 = document.getElementById("ptlt5").innerHTML;
			
			f1 = document.getElementById("govt").innerHTML;
			f2 = document.getElementById("pubt").innerHTML;
			
			ff2 = parseInt(f2) - parseInt(v2);
			
			document.getElementById("pubt").innerHTML = ff2;
			ttl = parseInt(f1) + parseInt(ff2);
			document.getElementById("pc_tot").innerHTML = ttl;
		}
		
		jQuery("#ptl1t5_price").val(v2);
	});

	//
	page_loaded = true;
	
	headerHeight = jQuery('#gkHeader').outerHeight();
	// smooth anchor scrolling
	//new SmoothScroll(); 
	// style area
	if(jQuery('#gkStyleArea')){
		jQuery('#gkStyleArea').find('a').each(function(i,element){
			jQuery(element).click(function(e){
	            e.preventDefault();
	            e.stopPropagation();
				changeStyle(i+1);
			});
		});
	}
	// font-size switcher
	if(jQuery('#gkTools') && jQuery('#gkMainbody')) {
		var current_fs = 100;
		
		jQuery('#gkMainbody').css('font-size', current_fs+"%");
		
		jQuery('#gkToolsInc').click(function(e){ 
			e.stopPropagation();
			e.preventDefault(); 
			if(current_fs < 150) {  
				jQuery('#gkMainbody').animate({ 'font-size': (current_fs + 10) + "%"}, 200); 
				current_fs += 10; 
			} 
		});
		jQuery('#gkToolsReset').click(function(e){ 
			e.stopPropagation();
			e.preventDefault(); 
			jQuery('#gkMainbody').animate({ 'font-size' : "100%"}, 200); 
			current_fs = 100; 
		});
		jQuery('#gkToolsDec').click(function(e){ 
			e.stopPropagation();
			e.preventDefault(); 
			if(current_fs > 70) { 
				jQuery('#gkMainbody').animate({ 'font-size': (current_fs - 10) + "%"}, 200); 
				current_fs -= 10; 
			} 
		});
	}
	// K2 font-size switcher fix
	if(jQuery('#fontIncrease') && jQuery('.itemIntroText')) {
		jQuery('#fontIncrease').click(function() {
			jQuery('.itemIntroText').attr('class', 'itemIntroText largerFontSize');
		});
		
		jQuery('#fontDecrease').click( function() {
			jQuery('.itemIntroText').attr('class', 'itemIntroText smallerFontSize');
		});
	}
	
	if(jQuery('#system-message-container a.close')){
		  jQuery('#system-message-container').find('a.close').each(function(i, element){
		  		jQuery('#system-message-container').css({'display' : 'block'});	
	           jQuery(element).click(function(e){
	           		e.preventDefault();
	           		e.stopPropagation();
	                jQuery(element).parents().eq(2).fadeOut();
	                (function() {
	                     jQuery(element).parents().eq(2).css({'display': 'none'});
	                }).delay(500);
	           });
	      });
	 } 
	
	// create the list of elements to animate
	jQuery('.gkHorizontalSlideRightColumn').each(function(i,element) {
		elementsToAnimate.push(['animation', element, jQuery(element).offset().top]);
	});
	
	jQuery('.layered').each(function(i,element) {
		elementsToAnimate.push(['animation', element, jQuery(element).offset().top]);
	});
	
	jQuery('.gkPriceTableAnimated').each(function(i,element) {
		elementsToAnimate.push(['queue_anim', element, jQuery(element).offset().top]);
	});
});

//
jQuery(window).scroll(function() {
	// menu animation
	
	
	if(page_loaded && jQuery('body').hasClass('imageBg')) {
		// if menu is not displayed now
		if(jQuery(window).scrollTop() > headerHeight && !jQuery('#gkMenuWrap').hasClass('active')) {
			//document.id('gkHeaderNav').inject(document.id('gkMenuWrap'), 'inside');
			jQuery('#gkMenuWrap').append(jQuery('#gkHeaderNav'));
			jQuery('#gkHeader').attr('class', 'gkNoMenu');
			// hide
			jQuery('#gkMenuWrap').attr('class', 'active');
		}
		//
		if(jQuery(window).scrollTop() <= headerHeight && jQuery('#gkMenuWrap').hasClass('active')) {
			jQuery('#gkHeader').first('div').css('display', 'block');
			jQuery('#gkHeader').first('div').prepend(jQuery('#gkHeaderNav'));
			jQuery('#gkHeader').attr('class', '');
			jQuery('#gkMenuWrap').attr('class', '');
		}
	}
	// animate all right sliders
	if(elementsToAnimate.length > 0) {		
		// get the necessary values and positions
		var currentPosition = jQuery(window).scrollTop();
		var windowHeight = jQuery(window).outerHeight();
		
		// iterate throught the elements to animate
		if(elementsToAnimate.length) {
			for(var i = 0; i < elementsToAnimate.length; i++) {
				if(elementsToAnimate[i][2] < currentPosition + (windowHeight / 2)) {
					// create a handle to the element
					var element = elementsToAnimate[i][1];
					// check the animation type
					if(elementsToAnimate[i][0] == 'animation') {
						//console.log('(XXX)' + elementsToAnimate[i][2]);
						gkAddClass(element, 'loaded', false);
						// clean the array element
						elementsToAnimate[i] = null;
					}
					// if there is a queue animation
					else if(elementsToAnimate[i][0] == 'queue_anim') {
						//console.log('(XXX)' + elementsToAnimate[i][2]);
						jQuery(element).find('dl').each(function(j, item) {
							gkAddClass(item, 'loaded', j);
						});
						// clean the array element
						elementsToAnimate[i] = null;
					}
				}
			}
			// clean the array
			elementsToAnimate = elementsToAnimate.clean();
		}
	}
});
//
function gkAddClass(element, cssclass, i) {
	var delay = jQuery(element).attr('data-delay');
	
	if(!delay) {
		delay = (i !== false) ? i * 150 : 0;
	}

	setTimeout(function() {
		jQuery(element).addClass(cssclass);
	}, delay);
}
//

jQuery(window).ready(function() {
	//
	var menuwrap = new jQuery('<div />', {
		'id': 'gkMenuWrap'
	});
	
	//
	jQuery('body').append(menuwrap);
	//
	if(!jQuery('body').hasClass('imageBg')) {
		jQuery('#gkMenuWrap').append(jQuery('#gkHeaderNav'));
		jQuery('#gkHeader').attr('class', 'gkNoMenu');
		jQuery('#gkHeader > div').first().css('display', 'none');
		jQuery('#gkMenuWrap').attr('class', 'active');
	}
	//
	// some touch devices hacks
	//
	
	// hack modal boxes ;)
	jQuery('a.modal').each(function(i,link) {
		// register start event
		var lasttouch = [];
		// here
		jQuery(link).bind('touchstart', function(e) {
			lasttouch = [link, new Date().getTime()];
		});
		// and then
		jQuery(link).bind('touchend', function(e) {
			// compare if the touch was short ;)
			if(lasttouch[0] == link && Math.abs(lasttouch[1] - new Date().getTime()) < 500) {
				window.location = jQuery(link).attr('href');
			}
		});
	});
});

// Function to change styles
function changeStyle(style){
	var file1 = $GK_TMPL_URL+'/css/style'+style+'.css';
	var file2 = $GK_TMPL_URL+'/css/typography/typography.style'+style+'.css';
	var file3 = $GK_TMPL_URL+'/css/typography/typography.iconset.style'+style+'.css';
	jQuery('head').append('<link rel="stylesheet" href="'+file1+'" type="text/css" />');
	jQuery('head').append('<link rel="stylesheet" href="'+file2+'" type="text/css" />');
	jQuery('head').append('<link rel="stylesheet" href="'+file3+'" type="text/css" />');
	jQuery.cookie('gk_simplicity_j30_style', style, { expires: 365, path: '/' });
}

jQuery(window).load(function() {
	if(elementsToAnimate.length > 0) {		
		// get the necessary values and positions
		var currentPosition = jQuery(window).scrollTop();
		var windowHeight = jQuery(window).outerHeight();
		
		// iterate throught the elements to animate
		if(elementsToAnimate.length) {
			for(var i = 0; i < elementsToAnimate.length; i++) {
				if(elementsToAnimate[i][2] < currentPosition + (windowHeight / 2)) {
					// create a handle to the element
					var element = elementsToAnimate[i][1];
					// check the animation type
					if(elementsToAnimate[i][0] == 'animation') {
						//console.log('(XXX)' + elementsToAnimate[i][2]);
						gkAddClass(element, 'loaded', false);
						// clean the array element
						elementsToAnimate[i] = null;
					}
					// if there is a queue animation
					else if(elementsToAnimate[i][0] == 'queue_anim') {
						//console.log('(XXX)' + elementsToAnimate[i][2]);
						jQuery(element).find('dl').each(function(j, item) {
							gkAddClass(item, 'loaded', j);
						});
						// clean the array element
						elementsToAnimate[i] = null;
					}
				}
			}
			// clean the array
			elementsToAnimate = elementsToAnimate.clean();
		}
	}
});

//Function for services tab
jQuery(document).ready(function() {
		jQuery('.tabb-links li a').on('click', function(e)  {
		var currentAttrValue = jQuery(this).attr('href');
 
		// Show/Hide Tabs
		jQuery('.tabb-content ' + currentAttrValue).show().siblings().hide();
	
		// Change/remove current tab to active
		jQuery(this).parent('li').addClass('active').siblings().removeClass('active');
		return false;
	});
});